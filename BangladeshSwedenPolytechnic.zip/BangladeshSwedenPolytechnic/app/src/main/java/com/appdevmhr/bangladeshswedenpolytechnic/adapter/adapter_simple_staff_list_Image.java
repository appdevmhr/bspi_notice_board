package com.appdevmhr.bangladeshswedenpolytechnic.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.appdevmhr.bangladeshswedenpolytechnic.R;
import com.appdevmhr.bangladeshswedenpolytechnic.model.Model_simple_staff_list;
import com.appdevmhr.bangladeshswedenpolytechnic.simpleMethod;
import com.appdevmhr.bangladeshswedenpolytechnic.ui.administation.staff_list_in_details;
import com.appdevmhr.bangladeshswedenpolytechnic.ui.setPeople;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class adapter_simple_staff_list_Image extends RecyclerView.Adapter<adapter_simple_staff_list_Image.viewholder> implements simpleMethod {

    Context context;
    ArrayList<Model_simple_staff_list> list;

    public adapter_simple_staff_list_Image(Context context, ArrayList<Model_simple_staff_list> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public viewholder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.simple_staff_list, viewGroup, false);
        return new viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull viewholder viewholder, int i) {
        Model_simple_staff_list model = list.get(i);
        viewholder.Name.setText(list.get(i).getSimple_staff_list_Name());
        viewholder.Post.setText(list.get(i).getSimple_staff_list_post());
        Picasso.get().load(list.get(i).getImagelink()).placeholder(R.drawable.ic_baseline_account_circle_24).into(viewholder.Photo);
        viewholder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                setIntentForSetPeaple(context, setPeople.class, "officeStaffInfo", model.getSimple_staff_list_Name());
                return false;
            }
        });
        viewholder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, staff_list_in_details.class);
                intent.putExtra("name", model.getSimple_staff_list_Name());
                intent.putExtra("post", model.getSimple_staff_list_post());
                intent.putExtra("section", model.getSection());
                intent.putExtra("homeDistrict", model.getHomeDistrict());
                intent.putExtra("education", model.getEducation());
                intent.putExtra("govtJobJoiningDate", model.getGovtJobJoiningDate());
                intent.putExtra("currentPositionJoinningDate", model.getCurrentPositionJoinningDate());
                intent.putExtra("currentInstituteJoinningDate", model.getCurrentInstituteJoinningDate());
                intent.putExtra("mobile", model.getMobile());
                intent.putExtra("email", model.getEmail());
                intent.putExtra("photo", model.getSimple_staff_list_Image());
                intent.putExtra("photoLink", model.getImagelink());
                context.startActivity(intent);

            }
        });

    }



    @Override
    public int getItemCount() {
        return list.size();
    }

    public class viewholder extends RecyclerView.ViewHolder {
        TextView Name, Post;
        ImageView Photo;
        Button view_details;

        public viewholder(@NonNull View itemView) {
            super(itemView);
            Name = itemView.findViewById(R.id.simple_staff_list_Name);
            Post = itemView.findViewById(R.id.simple_staff_list_post);
            Photo = itemView.findViewById(R.id.simple_staff_list_Image);
            view_details = itemView.findViewById(R.id.Simple_staff_list_Button);
        }
    }
}
